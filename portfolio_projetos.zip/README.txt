Nessa página eu demonstro minhas habilidades de resolver problemas de negócio utilizando conceitos e ferramentas da Ciência de Dados através de projetos com dados públicos.

Você vai encontrar também minhas experiências profissionais, habilidades, ferramentas e conceitos envolvendo a Ciência de Dados.

Sinta-se à vontade para acessar o link no final da página.

https://fgandrade.github.io/portfolio_projetos/
